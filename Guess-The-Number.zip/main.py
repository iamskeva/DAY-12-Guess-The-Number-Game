import random
from art import logo

print(logo)
print("Welcone to the Number Guessing Game!")
print("I'm thinking of a number between 1 - 100.")

number = random.randint(1,100)

choice = input("Choose a difficulty. Type 'easy' or 'hard': ")

easy_attempt = 10
hard_attempt = 5
attempt = 0

if choice == "hard":
  
  for i in range (5):

    attempt = i
    new_attempt = hard_attempt - attempt

    print(f"You have {new_attempt} attempts remaining to guess the number")
    guess = int(input("Make a guess: "))

    if guess > number and new_attempt == 1:
      print("Too high. \nGame over!")
    elif guess < number and new_attempt == 1:
      print("Too low. \nGame over!")
    elif guess > number:
      print("Too high. \nGuess again.")
    elif guess < number:
      print("Too low. \nGuess again.")
    else:
      print(f"You got it! The answer was {number}")
      break
    

elif choice == "easy":

  for i in range (10):

    attempt = i
    new_attempt = easy_attempt - attempt

    print(f"You have {new_attempt} attempts remaining to guess the number")
    guess = int(input("Make a guess: "))

    if guess > number and new_attempt == 1:
      print("Too high. \nGame over!")
    elif guess < number and new_attempt == 1:
      print("Too low. \nGame over!")
    elif guess > number:
      print("Too high. \nGuess again.")
    elif guess < number:
      print("Too low. \nGuess again.")
    else:
      print(f"You got it! The answer was {number}")
      break

else:
  print("Invalid input")